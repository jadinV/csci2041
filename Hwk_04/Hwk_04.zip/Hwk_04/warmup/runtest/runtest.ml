open Tests

let () = 
  ListSetTests.test1 ();
  ListSetTests.test2 ();
  ListSetTests.test3 ();

  TreeSetTests.test1 ();
  TreeSetTests.test2 ();
  TreeSetTests.test3 ()
