open Tests

let () = ListMapTests.test ()

let () = TreeMapTests.test ()

let () = ListMapImplTests.test ()

let () = TreeMapImplTests.test ()
