open Tests

let () = 
  test2 ();
  test3 ();
  test4 ();
  test5 ();
  test6 ()
