open Tests

let () = 
  test1 ();
  test2 ();
  test3 ();
  test4 ()
