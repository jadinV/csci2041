
open Warmup_tests

let _ = test_freevars ();
        test_eval ()
