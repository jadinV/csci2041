
open Mastery_tests

let _ = test_exception ();
        test_try_exception ()
